import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
// import Chart from 'chart.js';
let command1 = [19.5, 20.6, 20.7, 20.8, 21, 23.6, 24, 24.5, 26.5, 27, 29.5, 30];
let command2 = [40.5, 40.6, 40.7, 40.8, 41, 43.6, 44, 54.5, 56.5, 57, 59.5, 60];
let command3 = [70.5, 69.3, 65.5, 63.7, 61, 50.6, 50, 48.5, 46.5, 42, 41, 40];
// let command4 = [19.5, 20.3, 20.5, 20.7, 21, 23.6, 24, 24.5, 26.5, 27, 29.5, 30];
let count = 0;
let multiOptions = {
  responsive: true,
  scales: {
    x: {
      display: true,
      title: {
        display: true,
        text: 'Time(s)'
      }
    },
    y: {
      type: 'linear' as const,
      display: true,
      position: 'right' as const,
      min: 0,
      max: 100,
      ticks: {
        stepSize: 10
      },
      grid: {
        drawOnChartArea: false
      },
      title: {
        display: true,
        text: 'Setpoint'
      }
    },
    y1: {
      type: 'linear' as const,
      display: true,
      position: 'right' as const,
      min: 0,
      max: 100,
      ticks: {
        stepSize: 10
      },
      grid: {
        drawOnChartArea: false
      },
      title: {
        display: true,
        text: 'Position'
      }
    }
  },
  plugins: {
    legend: {
      display: true
    },
    title: {
      display: true,
      text: 'Multi Step Test Result'
    },
    zoom: {
      zoom: {
        wheel: {
          enabled: true
        },
        pinch: {
          enabled: true
        }
      },
      limits: {
        y: { min: 0, max: 1 },
        y1: { min: 0, max: 100 }
      },
      pan: {
        enabled: true,
        mode: 'xy'
      },
      mode: 'xy'
    }
  }
}
let positionList: any = [];
let setPointList: any = [];
let graphlabels: any = [];

let setPointUserInputList: any = [
  {
    startPosition: 20,
    stopPosition: 30
  },
  {
    startPosition: 40,
    stopPosition: 50
  },
  {
    startPosition: 70,
    stopPosition: 40
  }
]


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'school-app';
  public isExpanded = false;

  public toggleMenu() {
    this.isExpanded = !this.isExpanded;
  }


  ngOnInit(): void {
    // this.lineChart();
  //   let ValpostionList = [
  //     20.06802749633789,
  //     20.40816307067871,
  //     20.40816307067871,
  //     20.06802749633789,
  //     20.74829864501953,
  //     23.46938705444336,
  //     26.53061294555664,
  //     29.59183692932129,
  //     29.761905670166016,
  //     29.25170135498047,
  //     29.25170135498047,
  //     29.421768188476562,
  //     29.761905670166016,
  //     29.761905670166016,
  //     29.761905670166016,
  //     29.93197250366211,
  //     29.761905670166016,
  //     30.102041244506836,
  //     29.93197250366211,
  //     30.27210807800293,
  //     30.27210807800293,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.27210807800293,
  //     30.27210807800293,
  //     30.27210807800293,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.442176818847656,
  //     29.93197250366211,
  //     30.27210807800293,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.102041244506836,
  //     30.27210807800293,
  //     29.93197250366211,
  //     30.27210807800293,
  //     30.27210807800293,
  //     30.27210807800293,
  //     1.1326483154161515e-11,
  //   ]

  //   console.log('ValpostionList----------------', ValpostionList);

  //   ValpostionList.forEach((valObj) => {
  //     let precisionvalFirst = this.toPrecisionVal(valObj);
  //     console.log('valObj--------------------------', valObj);
  //     console.log('precisionvalFirst----------------', precisionvalFirst);
  //     console.log('===========================================');
  //   })
  // //  console.log('23.46938705444336', this.toPrecisionVal(1.5074532526958413e+35));

  }
  toPrecisionVal(x:any) {
    if (Math.abs(x) < 1.0) {
      var e = parseInt(x.toString().split('e-')[1]);
      if (e) {
          x *= Math.pow(10,e-1);
          x = '0.' + (new Array(e)).join('0') + x.toString().substring(2);
      }
    } else {
      var e = parseInt(x.toString().split('+')[1]);
      if (e > 20) {
          e -= 20;
          x /= Math.pow(10,e);
          x += (new Array(e+1)).join('0');
      }
    }
    return x;
  }
  lineChart() {
    const ctx = document.getElementById('lineChart') as HTMLCanvasElement;

    setInterval(() => {
      count++;
      console.log('count------------>', count);
      if (count === 1) {
        setPointList.push(setPointUserInputList[count - 1].startPosition);
        command1.forEach((value) => {
          positionList.push(value);
        })
        console.log('Set {Point Value=========1111111111====>', positionList);
        // graphlabels =[1,2,3,4,5,6,7,8,9,10,12]
        // for(let i=1;i<=setPointList.length;i++){
        //   graphlabels.push(i);
        // }
        for (let i = 1; i < command1.length; i++) {
          setPointList.push(setPointUserInputList[count - 1].stopPosition);
          console.log('Set {Point Value=========33333222====>', setPointList);
        }
      }
      console.log('Set {Point Value=========424424====>', setPointList);
      if (count === 2) {
        setPointList.push(setPointUserInputList[count - 1].startPosition);
        command2.forEach((value) => {
          positionList.push(value);
        })
        console.log('Set {Point Value=====22222========>', positionList);
        // for(let i=1;i<=setPointList.length;i++){
        //   graphlabels.push(i);
        // }
        for (let i = 1; i < command2.length; i++) {
          setPointList.push(setPointUserInputList[count - 1].stopPosition);
          console.log('Set {Point Value=========33333222====>', setPointList);
        }
      }
      if (count === 3) {
        setPointList.push(setPointUserInputList[count - 1].startPosition);
        command3.forEach((value) => {
          positionList.push(value);
        })
        console.log('Set {Point Value====3333=========>', positionList);
        // for(let i=1;i<=setPointList.length;i++){
        //   graphlabels.push(i);
        // }
        for (let i = 1; i < positionList.length; i++) {
          setPointList.push(setPointUserInputList[count - 1].stopPosition);
          console.log('Set {Point Value=========33333222====>', setPointList);
        }
      }

      new Chart(ctx, {
        type: 'line',
        data: {
          labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],

          // labels: Array.from({ length: setPointList.length }, (_, i) => i),
          datasets: [
            {
              label: 'Set Point',
              data: setPointList,
              borderColor: 'red',
              fill: false,
              stepped: 'after'
            },
            {
              label: 'Value Position',
              data: positionList,
              borderColor: 'blue',
              fill: false,
              tension: 0.2,
            }
          ]
        },
        options: multiOptions
      })
    }, 5000)

  }
}
