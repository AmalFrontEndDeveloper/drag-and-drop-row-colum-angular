import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { LayoutComponent } from './common/layout/layout.component';
import { SideNavConfigurationComponent } from './common/side-nav-configuration/side-nav-configuration.component';
import { ConfigurationSummaryComponent } from './common/configuration-summary/configuration-summary.component';
import { CustomTableComponent } from './core/custom-table/custom-table.component';
import { ErrorComponentComponent } from './shared/error-component/error-component.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LayoutComponent,
    SideNavConfigurationComponent,
    ConfigurationSummaryComponent,
    CustomTableComponent,
    ErrorComponentComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
