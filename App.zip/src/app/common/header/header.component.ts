import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { MatSidenav } from '@angular/material/sidenav';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @ViewChild('sidenav') sidenav: MatSidenav | undefined;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  route: any;
  loginUser?:string;
  constructor(public router: Router, public location: Location) {
    router.events.subscribe((val: any) => {
      this.route = location.path();
      console.log('route-------------', this.route);
    });
  }
  ngOnInit(): void {
    let user = JSON.parse(localStorage.getItem('userInfo') || '{}');
    this.loginUser = user.userInfo[0].Name;
  }
}
