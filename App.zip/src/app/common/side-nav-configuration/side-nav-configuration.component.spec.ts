import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SideNavConfigurationComponent } from './side-nav-configuration.component';

describe('SideNavConfigurationComponent', () => {
  let component: SideNavConfigurationComponent;
  let fixture: ComponentFixture<SideNavConfigurationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SideNavConfigurationComponent]
    });
    fixture = TestBed.createComponent(SideNavConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
