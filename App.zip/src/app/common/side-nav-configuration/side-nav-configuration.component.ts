import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-side-nav-configuration',
  templateUrl: './side-nav-configuration.component.html',
  styleUrls: ['./side-nav-configuration.component.scss']
})
export class SideNavConfigurationComponent {
  @Input() isExpanded: boolean | any;
  @Output() toggleMenu = new EventEmitter();
  public route: any;
  pagetitle?: string;
  constructor(public router: Router, public location: Location) {
    router.events.subscribe((val: any) => {
      this.route = location.path();
      console.log('route-------------', this.route);
    });
  }
  public routeLinks = [
    { link: "/admin/user", name: "User", icon: "person" },
    { link: "/admin/dashboard", name: "Dashboard", icon: "dashboard" },
    { link: "/admin/language", name: "Language", icon: "language" },
    { link: "/admin/banners", name: "Banners", icon: "wallpaper" },
    { link: "/admin/city", name: "Cities", icon: "location_city" },
    { link: "/admin/restaurants", name: "Restaurants", icon: "apartment" },
    { link: "/admin/staff", name: "Staff", icon: "account_circle" },
    { link: "/admin/driver", name: "Driver", icon: "person_pin_circle" },
    { link: "/admin/role", name: "Role", icon: "shield_person" },
    { link: "/admin/login", name: "Logout", icon: "logout" },
  ];
}
