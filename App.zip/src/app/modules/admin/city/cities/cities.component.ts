import { Component, ViewChild } from '@angular/core';

import {CdkDragDrop, CdkDropList, CdkDrag, moveItemInArray} from '@angular/cdk/drag-drop';
import { MatTable } from '@angular/material/table';
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  quantity: number;
}

export const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H', quantity: 100},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He', quantity: 100},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li', quantity: 100},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be', quantity: 100},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B', quantity: 100},
];
@Component({
  selector: 'app-cities',
  templateUrl: './cities.component.html',
  styleUrls: ['./cities.component.scss']
})
export class CitiesComponent {
 
  @ViewChild('table', {static: true}) table: MatTable<PeriodicElement> | any;

  dropColumn(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex);
  }

  // @ViewChild('table', {static: true}) table: MatTable<PeriodicElement>;

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol', 'quantity'];
  dataSource = ELEMENT_DATA;

  drop(event: CdkDragDrop<string>) {
    const previousIndex = this.dataSource.findIndex(d => d === event.item.data);

    moveItemInArray(this.dataSource, previousIndex, event.currentIndex);
    this.table.renderRows();
  }
}

// const ELEMENT_DATA1: any = [
//   {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
//   {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
//   // More elements...
// ];
