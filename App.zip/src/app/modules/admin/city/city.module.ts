import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CityRoutingModule } from './city-routing.module';
import { CitiesComponent } from './cities/cities.component';
import { AddCityComponent } from './add-city/add-city.component';
import { CdkDrag, DragDropModule } from '@angular/cdk/drag-drop';
import { MatTableModule } from '@angular/material/table';
import {MatIconModule} from '@angular/material/icon';
import {CdkDragDrop, CdkDropList, moveItemInArray} from '@angular/cdk/drag-drop';
@NgModule({
  declarations: [
    CitiesComponent,
    AddCityComponent
  ],
  imports: [
    CommonModule,
    CityRoutingModule,
    DragDropModule,
    CdkDropList, CdkDrag, MatTableModule, MatIconModule
  ]
})
export class CityModule { }
