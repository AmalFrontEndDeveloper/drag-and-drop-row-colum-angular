import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DriverDetailComponent } from './driver-detail/driver-detail.component';
import { AddDriverComponent } from './add-driver/add-driver.component';

const routes: Routes = [
  { path: '', component: DriverDetailComponent },
  { path: 'add-driver', component: AddDriverComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DriverRoutingModule { }
