import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DriverRoutingModule } from './driver-routing.module';
import { DriverDetailComponent } from './driver-detail/driver-detail.component';
import { AddDriverComponent } from './add-driver/add-driver.component';


@NgModule({
  declarations: [
    DriverDetailComponent,
    AddDriverComponent
  ],
  imports: [
    CommonModule,
    DriverRoutingModule
  ]
})
export class DriverModule { }
