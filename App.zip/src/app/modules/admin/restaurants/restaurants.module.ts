import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RestaurantsRoutingModule } from './restaurants-routing.module';
import { AddRestaurantComponent } from './add-restaurant/add-restaurant.component';
import { RestaurantsComponent } from './restaurants/restaurants.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DragDropModule } from "@angular/cdk/drag-drop";
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [
    AddRestaurantComponent,
    RestaurantsComponent
  ],
  imports: [
    CommonModule,
    RestaurantsRoutingModule,
    MatSlideToggleModule,
    DragDropModule, FlexLayoutModule,
    MatTableModule,
    MatIconModule,
  ]
})
export class RestaurantsModule { }
