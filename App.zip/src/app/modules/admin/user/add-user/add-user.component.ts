import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user-detail/services/user.service';
import { Subscription } from 'rxjs';
export interface Role {
  Name: string;
  Status: string;
}
export interface Status {
  Status: string;
}
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})

export class AddUserComponent implements OnInit , OnDestroy {
  subscriptions: Subscription[] = [];
  adduserForm: FormGroup | any;
  username: any;
  dateofbirth: any;
  selectgender: any;
  selectreligion: any;
  roleList: Role[] = [
    { Name: 'Admin', Status: 'Active' },
    { Name: 'User', Status: 'Active' }
  ];
  statusList: Status[] = [
    { Status: 'Active' },
    { Status: 'InActive' }
  ];
  constructor(
    public userService: UserService,
    public router: Router,
    private fb: FormBuilder,
  ) { }
  ngOnInit() {
    this.createUser();
  }
  createUser() {
    this.adduserForm = new FormGroup({
      Name: new FormControl('', [Validators.required]),
      Email: new FormControl('', [Validators.required]),
      Password: new FormControl('', [Validators.required]),
      Phone: new FormControl('', [Validators.required]),
      RoleID: new FormControl('', [Validators.required]),
      IsActive: new FormControl('', [Validators.required]),
      Address: this.fb.array([])
    })
  }

  adduserlist(user: any) {
    console.log('Users', user);
    this.subscriptions?.push(this.userService.createUser(user).subscribe((res) => {
      console.log(user);
      this.router.navigate(['/user']);
    }))
  }

  get Address() {
    return this.adduserForm.controls["Address"] as FormArray;
  }

  addAddress() {
    const addressForm = this.fb.group({
      title: ['', Validators.required],
    });
    this.Address.push(addressForm);
  }

  deleteAddress(addressIndex: number) {
    this.Address.removeAt(addressIndex);
  }
  ngOnDestroy(): void {
    this.subscriptions?.forEach((s) => {
      return s.unsubscribe();
    });
  }
}
