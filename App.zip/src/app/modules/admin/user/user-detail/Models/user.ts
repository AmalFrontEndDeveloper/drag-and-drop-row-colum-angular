
export class UserRes {
  message?: string;
  statusCode?: number;
  data?: UserInfoDetail[]
}

export interface UserInfoDetail {
  UserId: number,
  Name: string,
  Email: string,
  Password: string,
  Phone: number,
  RoleID: number,
  IsActive: string,
  Address: string,
  CreatedDate: string
}