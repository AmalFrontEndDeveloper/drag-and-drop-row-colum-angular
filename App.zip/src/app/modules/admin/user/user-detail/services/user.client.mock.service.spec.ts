import { TestBed } from '@angular/core/testing';

import { UserClientMockService } from './user.client.mock.service';

describe('UserClientMockService', () => {
  let service: UserClientMockService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserClientMockService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
