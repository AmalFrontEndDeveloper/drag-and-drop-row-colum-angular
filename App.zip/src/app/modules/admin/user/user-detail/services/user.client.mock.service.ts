import { Injectable } from '@angular/core';
import { UserInterfaceClientService } from './userInterface.client.service';
import { Observable, of } from 'rxjs';
import { UserInfoDetail, UserRes } from '../Models/user';
import * as UserMock from '../mock-data/user.mock';
@Injectable({
  providedIn: 'root'
})
export class UserClientMockService implements UserInterfaceClientService {
  private readonly UserData = UserMock.user;
  User(): Observable<UserRes> {
    return of(this.UserData);
  }
  createUser(req:UserInfoDetail): Observable<UserInfoDetail> {
    return of();
  }
  deleteUser(req:UserInfoDetail): Observable<UserInfoDetail> {
    return of();
  }
}
