import { Injectable } from '@angular/core';
import { UserInterfaceClientService } from './userInterface.client.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { UserInfoDetail, UserRes } from '../Models/user';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserClientService implements UserInterfaceClientService {
  userInfo: any;
  constructor(public httpClient: HttpClient,) {
    this.userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  }
  User(): Observable<UserRes> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.userInfo.token}`,
    });
    return this.httpClient.get<UserRes>(`${environment.apiUrl}users/getAllusers`, { headers: headers }).pipe(tap(user => {
      console.log('user', user);
    }));
  }
  createUser(req: UserInfoDetail): Observable<UserInfoDetail> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.userInfo.token}`,
    });
    return this.httpClient.post<UserInfoDetail>(`${environment.apiUrl}users/createUser`, req, { headers: headers }).pipe(tap(user => {
      console.log('user', user);
    }));
  }
  deleteUser(req: UserInfoDetail): Observable<UserInfoDetail> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.userInfo.token}`,
    });
    return this.httpClient.post<UserInfoDetail>(`${environment.apiUrl}users/deleteUser`, {UserId:req}, { headers: headers }).pipe(tap(user => {
      console.log('user', user);
    }));
  }
}