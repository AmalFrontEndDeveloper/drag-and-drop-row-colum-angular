import { Injectable } from '@angular/core';
import { UserInterfaceClientService } from './userInterface.client.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, from } from 'rxjs';
import { UserInfoDetail, UserRes } from '../Models/user';
import { UserClientService } from './user.client.service';
import { UserClientMockService } from './user.client.mock.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  UserClientService: UserInterfaceClientService;
  constructor(public httpClient: HttpClient, private clientService: UserClientService, private clientMockService: UserClientMockService) {
    if (environment.isMock) {
      this.UserClientService = this.clientMockService;
    }
    else {
      this.UserClientService = this.clientService;
    }
  }
  User(): Observable<UserRes> {
    return from(this.UserClientService.User());
  }
  createUser(req:UserInfoDetail): Observable<UserInfoDetail> {
    return from(this.UserClientService.createUser(req));
  }
  deleteUser(req:UserInfoDetail): Observable<UserInfoDetail> {
    return from(this.UserClientService.deleteUser(req));
  }
}
