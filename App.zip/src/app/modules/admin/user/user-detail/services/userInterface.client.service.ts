import { Observable } from "rxjs";
import { UserInfoDetail, UserRes } from "../Models/user";

export interface UserInterfaceClientService {
  User(): Observable<UserRes>;
  createUser(req:UserInfoDetail): Observable<UserInfoDetail>;
  deleteUser(req:UserInfoDetail): Observable<UserInfoDetail>;
}
