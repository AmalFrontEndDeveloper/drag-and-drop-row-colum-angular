import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from './services/user.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit, OnDestroy {
  subscriptions: Subscription[] = [];
  displayedColumns: string[] = ['Name', 'Email', 'IsActive', 'action'];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator | any;
  @ViewChild(MatSort, { static: true }) sort: MatSort | any;
  environment: any;

  userdetail: any;
  userfulldetail: any;

  constructor(public router: Router, public UserService: UserService
    //  public userservice:UserService 
  ) { }
  ngOnInit() {
    this.getUser();
  }
  adduser() {
    this.router.navigate(['/user/add-user']);
  }

  getUser() {
    this.subscriptions?.push(this.UserService.User().subscribe((user: any) => {
      console.log('user-----------', user);
      this.userfulldetail = new MatTableDataSource(user.data);
      console.log(this.userfulldetail);
      this.userfulldetail.paginator = this.paginator;
      this.userfulldetail.sort = this.sort;
    }, (err) => {
    }))
  }
  DeleteUser(userId: any) {
    this.subscriptions?.push(this.UserService.deleteUser(userId).subscribe((res) => {
      this.getUser();
    }))
  }
  applyFilter(filterValue: any) {
    this.userfulldetail.filter = filterValue.target.value.trim().toLowerCase();
  }
  ngOnDestroy(): void {
    this.subscriptions?.forEach((s) => {
      return s.unsubscribe();
    });
  }
}
