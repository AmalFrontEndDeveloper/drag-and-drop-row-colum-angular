import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './services/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup | any;
  constructor(public loginService: LoginService, public router: Router) {

  }
  ngOnInit() {
    this.createLoginForm();
  }
  createLoginForm() {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required]),
      Password: new FormControl('', [Validators.required])
    })
  }
  login(form: any) {
    console.log(form);
    this.loginService.Login(form).subscribe((user: any) => {
      console.log('user-----------', user);
      this.router.navigate(['/admin-dashboard']);
      localStorage.setItem('userInfo',JSON.stringify(user.data));
      if (user && user.data) {
        this.router.navigate(['/admin-dashboard']);
      }
    },(err)=>{
      alert()
    })
  }
}
