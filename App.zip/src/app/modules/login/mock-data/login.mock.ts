import { LoginRes } from "../models/login";

export const login: LoginRes = {
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjoiYW1hbDk1QGdtYWlsLmNvbSIsImlhdCI6MTY5NTMxMzc4NiwiZXhwIjoxNjk1MzE3Mzg2fQ.E1pKNGUY69PHJUEDP3SBMScYGAYo3t4cceobQwM3_js",
  userInfo: [
    {
      UserId: 6,
      Name: "Amal",
      Email: "amal95@gmail.com",
      Password: "$2b$10$q9raykb65/eiCbPmiPlJB.aUuNvcOWiLzjtwftirVIPNJanFx23Da",
      Phone: 2147483647,
      RoleID: 1,
      IsActive: "Active",
      CreatedDate: "2023-09-21T16:23:54.236Z"
    }
  ]
}



// {
//   "message": "Success",
//   "statusCode": 200,
//   "data": {
//       "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjoiYW1hbDk1QGdtYWlsLmNvbSIsImlhdCI6MTY5NTMxMzc4NiwiZXhwIjoxNjk1MzE3Mzg2fQ.E1pKNGUY69PHJUEDP3SBMScYGAYo3t4cceobQwM3_js",
//       "userInfo": [
//           {
//               "UserId": 6,
//               "Name": "Amal",
//               "Email": "amal95@gmail.com",
//               "Password": "$2b$10$q9raykb65/eiCbPmiPlJB.aUuNvcOWiLzjtwftirVIPNJanFx23Da",
//               "Phone": 2147483647,
//               "RoleID": 1,
//               "IsActive": "Active",
//               "CreatedDate": "2023-09-21T16:23:54.236Z"
//           }
//       ]
//   }
// }