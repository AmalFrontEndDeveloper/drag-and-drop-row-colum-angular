export class LoginReq {
  email?: string;
  Password?: string
}
export class LoginRes {
  token?: string;
  userInfo?: UserInfo[]
}

export interface UserInfo {
  UserId: number,
  Name: string,
  Email: string,
  Password: string,
  Phone: number,
  RoleID: number,
  IsActive: string,
  CreatedDate: string
}