import { TestBed } from '@angular/core/testing';

import { LoginClientMockService } from './login.client.mock.service';

describe('LoginClientMockService', () => {
  let service: LoginClientMockService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginClientMockService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
