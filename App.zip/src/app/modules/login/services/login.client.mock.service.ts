import { Injectable } from '@angular/core';
import { LoginInterfaceClientService } from './logininterface.client.service';
import { Observable, of } from 'rxjs';
import { LoginReq, LoginRes } from '../models/login';
import * as loginMock from '../mock-data/login.mock';
@Injectable({
  providedIn: 'root'
})
export class LoginClientMockService implements LoginInterfaceClientService {
  private readonly loginData = loginMock.login;
  Login(req:LoginReq): Observable<LoginRes> {
    return of(this.loginData);
  }
}
