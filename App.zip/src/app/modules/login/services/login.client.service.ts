import { Injectable } from '@angular/core';
import { LoginInterfaceClientService } from './logininterface.client.service';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { LoginReq, LoginRes } from '../models/login';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginClientService implements LoginInterfaceClientService {
  constructor(public httpClient: HttpClient,) { }
  Login(req: LoginReq): Observable<LoginRes> {
    console.log('req', req);
    return this.httpClient.post<LoginRes>(`${environment.apiUrl}users/login`,req).pipe(tap(user => {
      console.log('user', user);
    }));
  }
}