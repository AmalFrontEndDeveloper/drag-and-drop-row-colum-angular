import { Injectable } from '@angular/core';
import { LoginInterfaceClientService } from './logininterface.client.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, from } from 'rxjs';
import { LoginReq, LoginRes } from '../models/login';
import { LoginClientService } from './login.client.service';
import { LoginClientMockService } from './login.client.mock.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loginClientService: LoginInterfaceClientService;
  constructor(public httpClient: HttpClient, private clientService: LoginClientService, private clientMockService: LoginClientMockService) {
    if (environment.isMock) {
      this.loginClientService = this.clientMockService;
    }
    else {
      this.loginClientService = this.clientService;
    }
  }
  Login(req: LoginReq): Observable<LoginRes> {
    return from(this.loginClientService.Login(req));
  }
}
