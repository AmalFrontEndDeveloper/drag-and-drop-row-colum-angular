import { Observable } from "rxjs";
import { LoginReq, LoginRes } from "../models/login";

export interface LoginInterfaceClientService {
  Login(req: LoginReq): Observable<LoginRes>;
}
