export const environment = {
  production: true,
  isMock:false
};
